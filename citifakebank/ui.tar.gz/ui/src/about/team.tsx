import React, {useEffect} from "react";
import {bind} from "@react-rxjs/core";
import {combineLatest, defer, merge, of, Subject, switchMap} from "rxjs";
import {createSignal} from "@react-rxjs/utils";

const fetchEmployees = async (search: string) =>
  fetch(`http://localhost:8080/about/team?search=${search}`);


const [newEmployee$, setNewEmployee] = createSignal<string>();
const [useNewEmployee] = bind(newEmployee$, "");



const [_search$, setSearch] = createSignal<string>();
const [useSearch, search$] = bind(_search$, "");

const newEmployees$ = new Subject<string>("");
const employees$ = combineLatest([merge(of("initial"), newEmployees$), search$]).pipe(
  switchMap(([, search]) => fetchEmployees(search))
);
const [useEmployees] = bind(employees$);
const employees$ = on("initial", "newEmployee").pipe(switchMap(fetchEmployees));
on(["initial", "newEmployee"], fetchEmployees);

combineLatest([search$]).pipe()

const saveNewEmployee = async (newEmployee: string) => {
  await fetch("http://localhost:8080/about/addteammate", {
    method: "POST",
    body: JSON.stringify({path: newEmployee})
  });
  newEmployees$.next("");
};

const Team = () => {
  const newEmployee = useNewEmployee();
  const employees = useEmployees();
  const search = useSearch();
  return (
    <div>
      <input value={newEmployee} onChange={e => setNewEmployee(e.currentTarget.value)} />
      <button onClick={() => saveNewEmployee(newEmployee)}>Save</button>
      <input value={search} onChange={e => setSearch(e.currentTarget.value)} />
      <>{employees}</>
    </div>
  );
};

export default Team;