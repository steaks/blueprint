import React from 'react';
import {Routes, Route} from "react-router-dom";
import Home from "./home/home";
import {Subscribe} from "@react-rxjs/core";
import Team from "./about/team";

const App = () => {
  return (
    <div>
      <Subscribe fallback={<></>}>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/about/team" element={<Team/>}/>
        </Routes>
      </Subscribe>
    </div>
  );
}

export default App;
